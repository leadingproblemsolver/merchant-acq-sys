import test from 'node:test';import assert from 'node:assert/strict';
import {parseCsv, allowedUrl,extractPublicLinks,getCandidateUrl} from './research-core.mjs';
test('CSV handles quotes and embedded commas',()=>assert.equal(parseCsv('company,website_url\n"Cafe, Doha",https://example.org\n')[0].company,'Cafe, Doha'));
test('CSV rejects unmatched quote',()=>assert.throws(()=>parseCsv('a\n"unfinished')));
test('Rejects file, localhost and embedded credentials',()=>{for(const u of ['file:///etc/passwd','http://localhost:3000','https://a:b@example.com'])assert.equal(allowedUrl(u),false)});
test('Allows HTTPS public profile',()=>assert.equal(allowedUrl('https://www.instagram.com/example/'),true));
test('Gets first known URL',()=>assert.equal(getCandidateUrl({instagram_url:'https://example.org'}),'https://example.org'));
test('Extracts customer-path links only',()=>assert.deepEqual(extractPublicLinks([{text:'Menu',href:'https://example.org/menu'},{text:'Home',href:'https://example.org/'}]).length,1));
