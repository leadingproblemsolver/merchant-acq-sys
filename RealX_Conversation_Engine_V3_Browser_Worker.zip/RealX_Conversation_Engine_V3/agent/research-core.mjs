export function allowedUrl(raw){
  try {const u=new URL(String(raw||''));return ['http:','https:'].includes(u.protocol)&&!['localhost','127.0.0.1','0.0.0.0'].includes(u.hostname)&&!u.hostname.endsWith('.local')&& !u.username && !u.password;}catch{return false;}
}
export function parseCsv(s){
  const rows=[];let row=[],field='',quoted=false;
  for(let i=0;i<s.length;i++){
    const c=s[i];
    if(c==='"'&&quoted&&s[i+1]==='"'){field+='"';i++;}
    else if(c==='"')quoted=!quoted;
    else if(c===','&&!quoted){row.push(field);field='';}
    else if((c==='\n'||c==='\r')&&!quoted){if(c==='\r'&&s[i+1]==='\n')i++;row.push(field);field='';if(row.some(x=>x.trim()))rows.push(row);row=[];}
    else field+=c;
  }
  if(quoted)throw Error('Malformed CSV quote');
  if(field||row.length){row.push(field);rows.push(row);}
  const [headers=[],...data]=rows;
  return data.map(vals=>Object.fromEntries(headers.map((h,i)=>[h.trim(),vals[i]||''])));
}
export const getCandidateUrl = row => row.website_url||row.website||row.instagram_url||row.source_url||row.url||'';
export function safeStem(name){return String(name||'merchant').normalize('NFKD').replace(/[^a-z0-9-]+/gi,'-').slice(0,60).replace(/^-|-$/g,'')||'merchant';}
export function extractPublicLinks(links){
  return links.filter(x=>allowedUrl(x.href)).filter(x=>/contact|book|menu|order|whatsapp|wa\.me|instagram/i.test(`${x.text} ${x.href}`)).slice(0,15);
}
