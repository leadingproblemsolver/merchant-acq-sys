# RealX browser research worker — no messaging
This is an additive worker for Conversation Engine V3, not an autonomous outbound spam bot. It opens the existing merchant-candidate CSV, visits public URLs, takes screenshots, extracts page titles and publicly visible contact/booking links, and outputs `agent/output/research.json`. Results are only *observations*, never verified business needs, owner identities, or proof of conversion.

Run from the V3 project root (Node 20+):

```sh
npm install --no-save playwright
npx playwright install chromium
node agent/research.mjs data/food_candidates.csv 5
node --test agent/research.test.mjs tests/*.test.mjs
```

Limits: some sites block automation or require login; report `REVIEW_REQUIRED` and inspect manually rather than bypassing restrictions. No automatic account creation, login, chat, checkout, sending, or meeting claims. No API key required. Copy confirmed observations to the existing V3 account record; V3's evidence and handoff gates remain authoritative.

Next integration, after authorization: Gmail API for message reconciliation, Google Calendar for mutually agreed bookings, and a server ledger. Prefer official APIs over clicking third-party inbox or booking interfaces.
