/** Public-page evidence collector. NO sending, logging in, checkout, or automated messaging. */
import {readFile, writeFile, mkdir} from 'node:fs/promises';
import {join, resolve} from 'node:path';
import {parseCsv, allowedUrl, getCandidateUrl, safeStem, extractPublicLinks} from './research-core.mjs';
const args=process.argv.slice(2);
const file=args[0]||'data/food_candidates.csv';
const max=Math.min(25,Math.max(1,Number(args[1]||5)));
const out=resolve('agent/output');await mkdir(out,{recursive:true});
let chromium;
try {({chromium}=await import('playwright'));}catch {console.error('Install first: npm install --no-save playwright && npx playwright install chromium');process.exit(1);}
const rows=parseCsv(await readFile(file,'utf8')).slice(0,max);
const browser=await chromium.launch({headless:true});
const result=[];
try {
  for(let i=0;i<rows.length;i++){
    const row=rows[i],url=getCandidateUrl(row),name=row.company||row.name||`candidate-${i+1}`;
    const item={account:name,source_url:url,checked_at:new Date().toISOString(),status:'NOT_VERIFIED',title:'',public_links:[],observation:'',screenshot:'',needs_human_review:true};
    if(!allowedUrl(url)){item.observation='No safe public URL available';result.push(item);continue;}
    const page=await browser.newPage({viewport:{width:1280,height:900}});
    try {
      const response=await page.goto(url,{waitUntil:'domcontentloaded',timeout:15000});
      await page.waitForTimeout(750);
      item.title=(await page.title()).slice(0,250);
      item.http_status=response?.status()??null;
      item.public_links=extractPublicLinks(await page.locator('a[href]').evaluateAll(as=>as.map(a=>({text:(a.innerText||'').trim().slice(0,80),href:a.href})).slice(0,150)));
      item.visible_text_excerpt=(await page.locator('body').innerText().catch(()=>'' )).slice(0,1200);
      const screenshot=`${String(i+1).padStart(2,'0')}-${safeStem(name)}.png`;
      await page.screenshot({path:join(out,screenshot),fullPage:false});item.screenshot=screenshot;
      item.status='PAGE_OBSERVED_NOT_BUSINESS_VERIFIED';
    } catch(e) {item.status='REVIEW_REQUIRED';item.observation=String(e.message||e).slice(0,240);}
    finally {await page.close();}
    result.push(item);console.log(`${i+1}/${rows.length} ${name}: ${item.status}`);
  }
} finally {await browser.close();}
await writeFile(join(out,'research.json'),JSON.stringify(result,null,2));
console.log(`Saved ${join(out,'research.json')} with source-linked findings. Do not treat as verified contacts.`);
