# RealX V3 — Business Functionality Gap Closure

Use with the existing RealX Conversation Engine V3 project. Do not rebuild the UI or invent integration success. Run one prompt at a time, return changed files, tests, and remaining external blockers. Source paths: src/conversation-app.mjs, src/conversation-core.mjs, src/realx-core.mjs, src/domain.mjs, api/gemini.mjs, server.mjs.

## Prompt A — Business workflow and gap audit (Gemini / DeepSeek)

You are the operator and principal engineer of a merchant acquisition team. Inspect EVERY existing file before proposing changes. The commercial outcome is a **mutually confirmed meeting with an eligible new merchant, accepted by a named RealX account executive**. The technical status quo is a local event ledger with deterministic ICP scoring, a scripted conversation mapper and optional Gemini API. Do not confuse local event entry with a real external action.

Trace, with actual function and line references, a merchant moving through: sourced → verified → existing-partner exclusion → authorized contact → sent/delivered → reply → decision-owner confirmation → need confirmation → meeting invitation → merchant acceptance → AE acceptance → meeting held → merchant activation. Classify each transition IMPLEMENTED, MANUAL, MISSING, or UNSAFE; define actor, incoming data, resulting event, provider/source receipt, failure path, and KPI denominator. Identify exact places where UI lets a user claim a business outcome without authentic evidence. Return the smallest 3 PR plan to make the **first five merchant conversations** executable. Do not add frameworks or scrape contacts. Existing code must remain functional.

## Prompt B — Implement real conversation execution (Gemini / DeepSeek)

Patch the current V3, not a greenfield project. Implement minimal operator-first contact workflow:
1. Explicit account eligibility status with RealX partner-check reference and date. Block new acquisition if existing partner; UNKNOWN cannot be silently treated as cleared.
2. An ATTEMPT form requiring channel, contacted role, date/time, factual note, allowed contact basis and receipt/reference. Draft generation is not SENT; don't increment the approach KPI on copying text.
3. A REPLY form requiring exact reply text, time, relationship to prior attempt, source reference, and response class. Reject orphan replies or distinguish inbound unsolicited leads.
4. Conversation mapper must consume the actual latest reply plus prior events. On DECLINED, stop; on WRONG_PERSON, route; on QUESTION, ask or answer only verified commercial terms; on INTERESTED, determine qualification and propose an authorized meeting.
5. A due follow-up queue by account, owner, due date, opt-out status, and permitted channel. No auto-send by default.
6. Separate self-entered references from externally verified Gmail/Calendar IDs. Keep UI plainly labeled.
7. Preserve CSV import, JSON backup, ICP profile scoring, and all V2 tests.

Tests: orphan reply rejected; copy is not contact; declined stops; old/duplicate events don't inflate distinct-account rates; follow-ups overdue sorted; excluded partner not solicited; buyer's verbatim objection preserved; malicious content displayed safely. Print exact commands/results and changed files.

## Prompt C — Close the meeting / AE handoff loop (Gemini / DeepSeek)

Implement meeting states: REQUESTED, PROPOSED, MERCHANT_CONFIRMED, AE_CONFIRMED, VERIFIED_BOOKED, HELD, NO_SHOW, CANCELLED, RESCHEDULED, AE_ACCEPTED. Do not silently map them to current generic stage order. Use existing addEvent and buildHandoff as migration points.

Requirements: a proposed time isn't a booking; meeting verified requires merchant acknowledgment plus a corresponding calendar provider ID or manual two-party confirmation explicitly labeled UNVERIFIED_PROVIDER. AE acceptance requires named AE and acknowledgment evidence, not merely logging an event. Track meetings per account with distinct meeting IDs, reschedules and cancellations. An AE handoff contains source, prior buyer words, confirmed objective, objections, meeting time/timezone, contact permission, and exact next owner.

Expose `booked`, `held`, `AE-accepted` as distinct numerators. Add end-to-end tests for no-confirmation, conflicting meeting time, rescheduling, duplicate calendar IDs, cancellation, no-show, and AE decline. Preserve existing event records through a versioned migration. If Calendar or Gmail isn't connected, provide a manual confirmation workflow, never fake sync.

## Prompt D — Optional provider connectors (after manual validation)

Add a server-side Gmail and Google Calendar adapter for an **authorized RealX account** using least-privilege OAuth. The existing local-only V3 remains operable offline. No credentials in client HTML. Never auto-send marketing. Implement draft creation, sent-message ID reconciliation, actual thread reply ingestion for owned authorized mailbox, merchant-confirmed calendar invite creation, AE calendar participation, and provider receipt references. Store only necessary fields; protect personal information and opt-outs. If the platform cannot support OAuth, do not simulate integration; return exact blocker and a manual verification fallback. Provide integration tests using fake providers plus one guarded live smoke-test checklist (not a claim of live completion).

## Required final response for every iteration

Return: FILES INSPECTED; CURRENT FUNCTIONING PATH; CHANGED FILES; BEFORE/AFTER USER ACTION; TESTS ACTUALLY EXECUTED; DEMONSTRATED EXTERNAL ACTION (or NONE); BUSINESS KPI AFFECTED; OPEN BLOCKERS; NEXT IRREVERSIBLE PROOF EVENT. Never claim qualified meeting, conversion, live Gemini, or RealX revenue based only on local mocked activity.
